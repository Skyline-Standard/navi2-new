#!/usr/bin/env python3
"""Re-create the Move In / Move Out report's STRUCTURE, not its source data.

Standalone Python / ReportLab reconstruction of an uploaded two-page report.
No source PDF, database, network access, resident data, or vendor runtime needed.
This is NOT the original ActiveReports or Rent Manager report definition.

Run:
    python -m pip install -r requirements.txt
    python move_in_move_out.py --output blank_report.pdf
    python move_in_move_out.py --input empty_report.json --output report.pdf

The blank preview uses empty visual row slots. It does not calculate or assert
any property totals. All summary and reconciliation values are caller-supplied.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence

from reportlab.lib.colors import HexColor, black
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas

# Measurements are in PDF points, with layout coordinates measured from the top.
PAGE_WIDTH, PAGE_HEIGHT = 612.0, 792.0  # US Letter, portrait
PAGE_TOP, BODY_BOTTOM = 36.0, 739.0
ROW_HEIGHT = 11.1992
BODY_SIZE, HEADING_SIZE = 8.0, 18.0
STRIPE_COLOR = "#BFE5FF"
DEFAULT_TITLE = "Move In / Move Out"


@dataclass(frozen=True)
class Column:
    key: str
    label: str
    x: float
    width: float
    align: str = "left"


# The two detail tables genuinely have DIFFERENT column widths.
MOVE_IN_COLUMNS = (
    Column("resident_name", "Resident Name", 57.60, 87.74),
    Column("account", "Acc", 146.53, 21.06),
    Column("unit", "Unit", 168.77, 52.65),
    Column("unit_type", "Unit Type", 222.61, 52.64),
    Column("address", "Address", 276.44, 91.25),
    Column("lease_start", "Lease Start", 368.88, 52.64, "right"),
    Column("lease_end", "Lease End", 422.71, 52.64, "right"),
    Column("move_in", "Move In", 476.54, 49.14, "right"),
    Column("move_out", "Move Out", 526.87, 49.13, "right"),
)
MOVE_OUT_COLUMNS = (
    Column("resident_name", "Resident Name", 57.60, 77.87),
    Column("account", "Acc", 136.66, 18.69),
    Column("unit", "Unit", 156.53, 46.73),
    Column("unit_type", "Unit Type", 204.44, 46.73),
    Column("address", "Address", 252.35, 80.99),
    Column("lease_start", "Lease Start", 334.53, 46.72, "right"),
    Column("lease_end", "Lease End", 382.43, 43.61, "right"),
    Column("move_in", "Move In", 427.23, 43.61, "right"),
    Column("move_out", "Move Out", 472.02, 43.61, "right"),
    Column("expected_move_out", "Exp. Move Out", 516.82, 59.18, "right"),
)
SUMMARY_COLUMNS = (
    Column("detail", "Detail", 161.64, 215.65),
    Column("value", "Value", 378.48, 71.88, "right"),
)
MOVEMENT_KEYS = frozenset(c.key for c in MOVE_OUT_COLUMNS)
SUMMARY_LABELS = (
    ("date_range", "Date Range"),
    ("days_in_range", "Days In Range"),
    ("move_ins", "Move Ins"),
    ("move_outs", "Move Outs"),
    ("net_change", "Net Change in Occupancy"),
    ("total_moves", "Total Move Ins / Move Outs"),
)
RECONCILIATION_KEYS = (
    "opening_date", "start_date", "end_date", "opening_occupancy",
    "move_ins", "move_outs", "opening_date_move_outs",
    "ending_date_move_outs", "ending_occupancy",
)


def _object(value: Any, context: str) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{context} must be a JSON object.")
    return value


def _allowed(value: Mapping[str, Any], keys: Sequence[str], context: str) -> None:
    unknown = set(value) - set(keys)
    if unknown:
        raise ValueError(f"Unknown key(s) in {context}: {', '.join(sorted(unknown))}")


def _text_value(value: Any, context: str) -> str:
    # Treat all values as presentation strings: do not reinterpret dates,
    # strip leading zeros from account numbers, or infer vendor accounting rules.
    if value is None:
        return ""
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise ValueError(f"{context} must be a string, finite number, or null.")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"{context} cannot be NaN or infinite.")
    return " ".join(str(value).split())


@dataclass
class PropertyGroup:
    property: str = "[Property]"
    rows: list[dict[str, str]] = field(default_factory=list)
    total: str = ""
    blank_rows: int = 0

    @classmethod
    def from_dict(cls, value: Any, context: str) -> PropertyGroup:
        obj = _object(value, context)
        _allowed(obj, ("property", "rows", "total", "blank_rows"), context)
        rows = obj.get("rows", [])
        if not isinstance(rows, list):
            raise ValueError(f"{context}.rows must be an array.")
        parsed = []
        for index, row in enumerate(rows):
            name = f"{context}.rows[{index}]"
            row = _object(row, name)
            _allowed(row, tuple(MOVEMENT_KEYS), name)
            parsed.append({key: _text_value(val, f"{name}.{key}")
                           for key, val in row.items()})
        slots = obj.get("blank_rows", 0)
        if type(slots) is not int or not 0 <= slots <= 10000:
            raise ValueError(f"{context}.blank_rows must be an integer from 0 to 10000.")
        return cls(
            property=_text_value(obj.get("property", "[Property]"), f"{context}.property"),
            rows=parsed,
            total=_text_value(obj.get("total", ""), f"{context}.total"),
            blank_rows=slots,
        )


@dataclass
class ReportData:
    title: str = DEFAULT_TITLE
    property: str = "[Property]"
    date_range: str = "[Start date] - [End date]"
    generated_at: str = "[Generated timestamp]"
    footer_system: str = "[System] - property management systems"
    footer_revision: str = "[Version]"
    move_ins: list[PropertyGroup] = field(default_factory=list)
    move_outs: list[PropertyGroup] = field(default_factory=list)
    summary: dict[str, str] = field(default_factory=dict)
    reconciliation: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, value: Any) -> ReportData:
        obj = _object(value, "report")
        _allowed(obj, tuple(cls.__dataclass_fields__), "report")
        result = cls()
        for key in ("title", "property", "date_range", "generated_at",
                    "footer_system", "footer_revision"):
            if key in obj:
                setattr(result, key, _text_value(obj[key], key))
        for key in ("move_ins", "move_outs"):
            groups = obj.get(key, [])
            if not isinstance(groups, list):
                raise ValueError(f"{key} must be an array of property groups.")
            setattr(result, key, [PropertyGroup.from_dict(g, f"{key}[{i}]")
                                  for i, g in enumerate(groups)])
        for key, allowed in (("summary", tuple(k for k, _ in SUMMARY_LABELS)),
                             ("reconciliation", RECONCILIATION_KEYS)):
            values = _object(obj.get(key, {}), key)
            _allowed(values, allowed, key)
            setattr(result, key, {k: _text_value(v, f"{key}.{k}") for k, v in values.items()})
        return result


def blank_template() -> dict[str, Any]:
    """Placeholder-only input. Blank slot counts match the reference's layout.

    9/15 are visual slot counts, NOT reported movement totals. Changing them
    changes the preview height. Nonempty `rows` replaces all blank slots.
    """
    return {
        "title": DEFAULT_TITLE,
        "property": "[Property]",
        "date_range": "[Start date] - [End date]",
        "generated_at": "[Generated timestamp]",
        "footer_system": "[System] - property management systems",
        "footer_revision": "[Version]",
        "move_ins": [{"property": "[Property]", "rows": [], "blank_rows": 9, "total": ""}],
        "move_outs": [{"property": "[Property]", "rows": [], "blank_rows": 15, "total": ""}],
        "summary": {key: "" for key, _ in SUMMARY_LABELS},
        "reconciliation": {
            "opening_date": "[Opening date]", "start_date": "[Start]", "end_date": "[End]",
            "opening_occupancy": "", "move_ins": "", "move_outs": "",
            "opening_date_move_outs": "", "ending_date_move_outs": "", "ending_occupancy": "",
        },
    }


class Composer:
    """First lay out pages; render second so 'Page X of Y' is correct.

    This avoids hard-coding a two-page report or buffering Canvas internals.
    The sparse second page in the blank preview reproduces the reference.
    """
    def __init__(self, data: ReportData, *, repeat_summary_headers: bool = False):
        self.data = data
        self.repeat_summary_headers = repeat_summary_headers
        self.pages: list[list[tuple[str, dict[str, Any]]]] = [[]]
        self.y = PAGE_TOP

    def add(self, operation: str, **values: Any) -> None:
        self.pages[-1].append((operation, values))

    def text(self, text: str, x: float, top: float, width: float,
             *, size: float = BODY_SIZE, style: str = "regular", align: str = "left") -> None:
        if text:
            self.add("text", text=text, x=x, top=top, width=width,
                     size=size, style=style, align=align)

    def new_page(self) -> None:
        self.pages.append([])
        self.y = PAGE_TOP

    def room(self, height: float) -> bool:
        if self.y + height > BODY_BOTTOM + 0.001:
            self.new_page()
            return False
        return True

    def heading(self, title: str, *, center: float = 306.0) -> None:
        self.text(title, center - 260, self.y + 1, 520,
                  size=HEADING_SIZE, style="bold", align="center")

    def table_header(self, columns: Sequence[Column], *, height: float = 10.8) -> None:
        for column in columns:
            self.text(column.label, column.x + 1, self.y + 1.25, column.width - 2,
                      style="bold", align="center")
            self.add("line", x1=column.x, x2=column.x + column.width,
                     top=self.y + height, thickness=0.5)
        self.y += height

    def group_label(self, group: PropertyGroup) -> None:
        self.text(group.property, 37, self.y + 1, 538, style="bold")
        self.y += ROW_HEIGHT

    def detail_row(self, values: Mapping[str, str], columns: Sequence[Column], index: int) -> None:
        if index % 2:
            left = columns[0].x
            right = columns[-1].x + columns[-1].width
            self.add("rect", x=left + 0.25, top=self.y + 0.25,
                     width=right - left - 0.5, height=ROW_HEIGHT - 0.5,
                     color=STRIPE_COLOR)
        for column in columns:
            self.text(values.get(column.key, ""), column.x + 1,
                      self.y + 1, column.width - 2, align=column.align)
        self.y += ROW_HEIGHT

    def movements(self, title: str, groups: Sequence[PropertyGroup],
                  columns: Sequence[Column], total_label: str) -> None:
        self.room(27 + 10.8 + 3 * ROW_HEIGHT)
        self.heading(title)
        self.y += 27
        self.table_header(columns)
        # Empty input retains the section's property / total structure.
        groups = groups or [PropertyGroup(property=self.data.property)]
        for group in groups:
            rows = group.rows or [{} for _ in range(group.blank_rows)]
            if not self.room(ROW_HEIGHT * (3 if rows else 2)):
                self.table_header(columns)
            self.group_label(group)
            for index, row in enumerate(rows):
                needed = ROW_HEIGHT * (2 if index == len(rows) - 1 else 1)
                if not self.room(needed):
                    self.table_header(columns)
                    self.group_label(group)
                self.detail_row(row, columns, index)
            self.room(ROW_HEIGHT)
            self.text(total_label, 37, self.y + 1, 158, style="bold")
            self.text(group.total, 196, self.y + 1, 19, style="bold", align="right")
            self.y += ROW_HEIGHT

    def summary_section(self, title: str, rows: Sequence[tuple[str, str]]) -> None:
        self.room(44.2208 + 11.6992 + ROW_HEIGHT)
        self.heading(title, center=297.0)
        self.y += 44.2208
        self.table_header(SUMMARY_COLUMNS, height=11.6992)
        for index, (detail, value) in enumerate(rows):
            if not self.room(ROW_HEIGHT) and self.repeat_summary_headers:
                self.table_header(SUMMARY_COLUMNS, height=11.6992)
            self.detail_row({"detail": detail, "value": value}, SUMMARY_COLUMNS, index)

    def compose(self) -> list[list[tuple[str, dict[str, Any]]]]:
        self.heading(self.data.title)
        self.text(f"Property: {self.data.property}", 36, 60.76, 540,
                  size=10, align="center")
        self.text(f"Date Range: {self.data.date_range}", 36, 75.736, 540,
                  size=9, style="italic", align="center")
        self.y = 95.76
        self.movements("Move In", self.data.move_ins, MOVE_IN_COLUMNS, "Total move ins in property")
        self.y += 7.55
        self.movements("Move Out", self.data.move_outs, MOVE_OUT_COLUMNS, "Total move outs in property")
        self.y += 9.8261
        self.summary_section("Report Summary", [(label, self.data.summary.get(key, ""))
                                                for key, label in SUMMARY_LABELS])
        self.y += 12.3842
        r = self.data.reconciliation
        opening = r.get("opening_date", "[Opening date]")
        start, end = r.get("start_date", "[Start]"), r.get("end_date", "[End]")
        # Preserve the original's six lines, including both boundary-date
        # move-out adjustments. The +/- signs belong to the layout; their
        # underlying counting / occupancy policy is deliberately NOT inferred.
        signed = lambda key, sign: f"{sign} {r[key]}" if r.get(key) else f"{sign} _____"
        self.summary_section("Occupancy Reconciliation", [
            (f"Occupancy on {opening}", r.get("opening_occupancy", "")),
            (f"Move Ins from {start} to {end}", signed("move_ins", "+")),
            (f"Move Outs from {start} to {end}", signed("move_outs", "-")),
            (f"Move Outs on {opening}", signed("opening_date_move_outs", "-")),
            (f"Move Outs on {end}", signed("ending_date_move_outs", "+")),
            (f"Occupancy on {end}", r.get("ending_occupancy", "")),
        ])
        return self.pages


def register_fonts(paths: Sequence[Path] | None = None) -> dict[str, str]:
    styles = ("regular", "bold", "italic")
    if paths is None:
        return dict(zip(styles, ("Helvetica", "Helvetica-Bold", "Helvetica-Oblique")))
    if len(paths) != 3:
        raise ValueError("Supply all three font files: regular, bold, and italic.")
    result = {}
    for style, path in zip(styles, paths):
        if not path.is_file():
            raise ValueError(f"Font file does not exist: {path}")
        name = f"ReportFont-{style}"
        pdfmetrics.registerFont(TTFont(name, str(path)))
        result[style] = name
    return result


def _fit(text: str, font: str, size: float, width: float, strict: bool) -> tuple[str, float]:
    measured = pdfmetrics.stringWidth(text, font, size)
    if measured <= width:
        return text, size
    # Preserve the table widths, but do not let text spill into adjacent cells.
    fitted_size = max(6.5, size * width / measured)
    if pdfmetrics.stringWidth(text, font, fitted_size) <= width + 0.001:
        return text, fitted_size
    if strict:
        raise ValueError("A cell cannot fit at the minimum font size; widen its column or shorten its text.")
    suffix = "..."
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if pdfmetrics.stringWidth(text[:mid] + suffix, font, fitted_size) <= width:
            lo = mid
        else:
            hi = mid - 1
    warnings.warn("A long cell was ellipsized to fit the reference layout. "
                  "Use --strict-fit to reject truncation.", stacklevel=3)
    return text[:lo] + suffix, fitted_size


def _draw_text(canvas: Canvas, fonts: Mapping[str, str], *, text: str, x: float,
               top: float, width: float, size: float, style: str, align: str,
               strict: bool) -> None:
    font = fonts[style]
    if font.startswith("Helvetica"):
        try:
            text.encode("cp1252")
        except UnicodeEncodeError as exc:
            raise ValueError("Text needs a Unicode font. Supply --font-regular, "
                             "--font-bold, and --font-italic.") from exc
    shown, fitted_size = _fit(text, font, size, width, strict)
    canvas.setFillColor(black)
    canvas.setFont(font, fitted_size)
    baseline = PAGE_HEIGHT - (top + 0.905 * size)
    if align == "right":
        canvas.drawRightString(x + width, baseline, shown)
    elif align == "center":
        canvas.drawCentredString(x + width / 2, baseline, shown)
    else:
        canvas.drawString(x, baseline, shown)


def build_report(output: str | Path, data: Mapping[str, Any] | None = None, *,
                 font_paths: Sequence[Path] | None = None, strict_fit: bool = False,
                 repeat_summary_headers: bool = False) -> int:
    """Write the report and return its page count.

    `None` produces the two-page blank preview. A mapping supplies ONLY display
    values; no SQL, API calls, filtering, aggregation, or occupancy calculations
    are performed. Pass reconciliation counts as unsigned display values.
    """
    report = ReportData.from_dict(blank_template() if data is None else data)
    fonts = register_fonts(font_paths)
    pages = Composer(report, repeat_summary_headers=repeat_summary_headers).compose()
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Render into memory so a validation / font failure never leaves a partial
    # PDF or truncates an existing output file.
    from io import BytesIO
    buffer = BytesIO()
    canvas = Canvas(buffer, pagesize=(PAGE_WIDTH, PAGE_HEIGHT), pageCompression=1)
    canvas.setTitle(report.title)
    canvas.setAuthor("")
    canvas.setCreator("Standalone structural reconstruction - Python / ReportLab")
    canvas.setSubject("Parameterized report template; not an original vendor report definition")
    for index, operations in enumerate(pages, start=1):
        for operation, values in operations:
            if operation == "text":
                _draw_text(canvas, fonts, strict=strict_fit, **values)
            elif operation == "rect":
                canvas.setFillColor(HexColor(values["color"]))
                canvas.rect(values["x"], PAGE_HEIGHT - values["top"] - values["height"],
                            values["width"], values["height"], stroke=0, fill=1)
            elif operation == "line":
                canvas.setStrokeColor(black)
                canvas.setLineWidth(values["thickness"])
                canvas.line(values["x1"], PAGE_HEIGHT - values["top"],
                            values["x2"], PAGE_HEIGHT - values["top"])
        footer = [
            (report.title, 37.0, 82.0, "left"),
            (report.generated_at, 123.0, 125.0, "left"),
            (f"Page {index} of {len(pages)}", 267.8, 72.0, "center"),
            (f"{report.footer_system}   rev.{report.footer_revision}", 352.39, 222.61, "right"),
        ]
        for text, x, width, align in footer:
            _draw_text(canvas, fonts, text=text, x=x, top=747.28, width=width,
                       size=7.5, style="italic", align=align, strict=strict_fit)
        canvas.showPage()
    canvas.save()
    output.write_bytes(buffer.getvalue())
    return len(pages)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", type=Path, help="JSON display bindings. Omit for a blank preview.")
    parser.add_argument("--output", type=Path, default=Path("blank_report.pdf"))
    parser.add_argument("--write-template", type=Path, help="Write empty JSON bindings and exit.")
    parser.add_argument("--strict-fit", action="store_true", help="Reject cells that need ellipsizing.")
    parser.add_argument("--repeat-summary-headers", action="store_true",
                        help="Repeat Detail / Value on continuation pages (off to match the original).")
    parser.add_argument("--font-regular", type=Path)
    parser.add_argument("--font-bold", type=Path)
    parser.add_argument("--font-italic", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.write_template:
            args.write_template.parent.mkdir(parents=True, exist_ok=True)
            args.write_template.write_text(json.dumps(blank_template(), indent=2) + "\n", encoding="utf-8")
            print(f"Wrote {args.write_template}")
            return 0
        fonts = [args.font_regular, args.font_bold, args.font_italic]
        if any(fonts) and not all(fonts):
            raise ValueError("Supply all three font flags together.")
        data = None
        if args.input:
            if args.input.resolve() == args.output.resolve():
                raise ValueError("Input and output paths must be different.")
            data = json.loads(args.input.read_text(encoding="utf-8"))
        count = build_report(args.output, data, font_paths=fonts if all(fonts) else None,
                             strict_fit=args.strict_fit,
                             repeat_summary_headers=args.repeat_summary_headers)
        print(f"Wrote {args.output} ({count} page{'s' if count != 1 else ''})")
        return 0
    except (OSError, ValueError, TypeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
