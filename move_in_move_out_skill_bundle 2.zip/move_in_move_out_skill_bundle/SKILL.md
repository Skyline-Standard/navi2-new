# Skill Brief: Move In / Move Out

**Source report:** Rent Manager → Move In / Move Out (date-ranged, default All Properties; two grouped sections — Move Ins, Move Outs — each with per-property totals, plus a Summary and an Occupancy Reconciliation block)
**Columns:** Resident, Acc. #, Unit, Unit Type, Address, Lease Start, Lease End, Move In, Move Out, (Move Outs section adds) Expected Move Out

## Trigger phrases
- "Show me move-ins and move-outs for [date range/property]"
- "How many move-outs this month?"
- "What's our occupancy change this week?"
- "Who moved in/out at [property]?"
- "Turnover report for [date range]"
- "What's our current occupancy?"

## Purpose
Answers: *over a given period, who moved in and who moved out (by property), what was the net change in occupancy, and how does the period's starting occupancy reconcile to its ending occupancy?* Used for turnover tracking, occupancy trend reporting, and auditing the portfolio's unit count.

## Required inputs
- **A date range (From/To).** Like Lease Expiration, this report answers a period-based question — a single default day isn't generally useful. Ask if not given.

## Optional inputs / defaults
- **Property filter** — default: All Properties
- **Unit type filter** — default: none
- Per-user memory: typical reporting cadence (weekly/monthly), preferred property scope

## Clarifying prompts
- No date range given → "What period — this week, this month, or a specific range?"
- "What's our occupancy" asked generically → clarify whether they want the current point-in-time occupancy number or the full move-in/move-out activity behind a change
- "Turnover" with no scope → ask property/date range before pulling


## Rent Manager data retrieval — use the native Reports endpoint

**Primary rule:** generate this skill from Rent Manager's native **Move In / Move Out report**, not by reconstructing the report from `Leases`, `Units`, or `Tenants`. The native report is authoritative for the two event sections, report totals, and Occupancy Reconciliation. Use raw resources only for explicitly requested drill-downs or as a fallback when native report execution is unavailable.

### 1. Resolve the native report

Use the existing authenticated NAVI Rent Manager connector and the client/location-scoped RM host. RM API calls use HTTPS and the configured `X-RM12Api-ApiToken`; do not create a separate login/session for this skill.

First query the Reports resource to discover the report definition and its parameters:

```http
GET Reports?embeds=ReportParameters&fields=ReportID,Name,Description,ReportParameters
```

From the returned collection, select the report whose `Name` is **Move In / Move Out**. Do **not** hard-code a guessed `ReportID`/enum value. Cache the resolved report identity only within the same RM company/location scope and invalidate it if the report is no longer returned.

The captured RM schema establishes that `Reports` exposes `ReportID`, `Name`, and `ReportParameters`. The exact nested parameter model and enum values are connector/runtime concerns, so inspect the returned report metadata rather than inventing parameter IDs or types.

### 2. Map the user's request to the report parameters

Build the report request from the parameters returned for **Move In / Move Out**. Match parameters by their returned identity/name, not by positional order. At minimum map:

- **From / start date** → user's requested period start
- **To / end date** → user's requested period end
- **Property / properties** → resolved canonical RM property IDs; default to all properties the caller is authorized to access
- **Unit type** → only when the user supplied one; otherwise preserve the report's default/no-filter behavior

Never send a display property name when the report parameter expects an ID. Resolve property names through RM first. If a property name is ambiguous, clarify before running the report. Preserve the property's/report's timezone when interpreting date boundaries.

Do not guess undocumented parameter keys, enum values, list serialization, or date formatting. Use the actual `ReportParameters` metadata returned by RM and the existing connector's validated report-parameter serializer.

### 3. Execute the report through the connector's Reports operation

After resolving the `ReportID` and parameter definitions, invoke the existing connector's **native report execution** operation for that report, passing the resolved report identity and parameter values. Request a structured/grid representation when the connector supports it; otherwise request the connector's supported export and parse it without changing RM's grouping/totals.

Conceptually the call is:

```text
run_native_rm_report(
  report_id = <ReportID returned by GET Reports>,
  parameters = {
    <returned From parameter>: <from_date>,
    <returned To parameter>: <to_date>,
    <returned Property parameter>: <authorized property IDs or report default>,
    <returned Unit Type parameter>: <unit type filter only if requested>
  }
)
```

`run_native_rm_report(...)` above is pseudocode for the existing connector capability — **not** a literal Rent Manager URL. The supplied API reference captures report metadata discovery but does not capture the HTTP method/path/body for report execution. Therefore this skill must call the connector's already-validated report execution primitive; it must not manufacture an endpoint such as `/Reports/{id}/Run`. If that primitive is not available in the runtime, return `unavailable` for the native report rather than silently rebuilding a supposedly equivalent report from raw lease records.

### 4. Parse the native report result

Preserve RM's report structure and labels. Extract:

1. **Move Ins** rows, grouped by property
2. **Move Outs** rows, grouped by property
3. Per-property totals for each section
4. **Summary** totals: Move Ins, Move Outs, Net Change in Occupancy
5. **Occupancy Reconciliation** exactly as returned by RM, including any day-boundary adjustment lines

For resident/event rows, retain these report columns when present: `Resident`, `Acc. #`, `Unit`, `Unit Type`, `Address`, `Lease Start`, `Lease End`, `Move In`, `Move Out`, and `Expected Move Out` in the Move Outs section. Treat the report's own grouping and totals as authoritative; do not recompute them from row count unless validating the parse.

### 5. Validation and completeness

- Confirm the report returned the requested date range and property scope before answering.
- Record the RM company/location, resolved `ReportID`, requested parameters, retrieval time, and accessible property scope with the result.
- If the native report call fails for one or more requested properties, do not present a portfolio total as complete. Mark the result `partial` and identify the omitted scope.
- A successful report with a section total of zero is a valid zero, not missing data.
- Do not substitute current `Units.IsVacant` or raw lease dates for the report's Occupancy Reconciliation.
- Do not count `Expected Move Out` as an actual move-out unless RM places the resident in the completed Move Outs result / supplies an actual `Move Out`.

### 6. Raw-resource fallback is diagnostic only

The `Leases` resource exposes `PropertyID`, `UnitID`, `TenantID`, `MoveInDate`, `MoveOutDate`, `ExpectedMoveOutDate`, and lease relationships, so it can be used to investigate a row or diagnose a native-report discrepancy. It is **not** the default source for this skill because reconstructing the native report can diverge on historical occupancy, exclusions, renewals, and day-boundary reconciliation. If native report execution is unavailable, say so rather than claiming a reconstructed result is the RM Move In / Move Out report.

## Output artifact — MUST use the bundled Python report generator

**Hard requirement:** when the user asks for the Move In / Move Out report itself, a PDF/export, or a full report, do **not** render the report directly in chat and do **not** create a new PDF layout. The final report artifact must be generated with the bundled `move_in_move_out.py` renderer in this skill package.

The renderer is presentation-only: it does not query Rent Manager, choose records, calculate totals, or calculate occupancy. The skill must first retrieve and parse the authoritative native RM Move In / Move Out report as described above, then transform that result into the renderer's bindings and call the Python file.

### Required bundled files

Keep these files with this skill and treat them as part of the report-generation contract:

- `move_in_move_out.py` — **required renderer; always use this file to generate the PDF**
- `report.schema.json` — accepted binding schema
- `layout_spec.json` — layout/reference specification
- `requirements.txt` — Python runtime dependency (`reportlab`)
- `empty_report.json` — example/blank binding object; do not use its placeholder values as report data
- `README.md` — renderer usage/reference
- `test_report.py` — renderer tests

`blank_report.pdf` is only a structural preview and must never be returned as a live report.

### Transform RM output into the Python bindings

Create a JSON-compatible binding object matching `report.schema.json`. Populate values from the parsed native RM report; do not invent missing values and do not infer totals that RM supplied separately.

```json
{
  "title": "Move In / Move Out",
  "property": "All Properties or selected property label",
  "date_range": "<display date range>",
  "generated_at": "<generation timestamp>",
  "footer_system": "Rent Manager",
  "footer_revision": "NAVI",
  "move_ins": [
    {
      "property": "<property name>",
      "rows": [
        {
          "resident_name": "<Resident>",
          "account": "<Acc. #>",
          "unit": "<Unit>",
          "unit_type": "<Unit Type>",
          "address": "<Address>",
          "lease_start": "<Lease Start>",
          "lease_end": "<Lease End>",
          "move_in": "<Move In>",
          "move_out": "<Move Out>",
          "expected_move_out": ""
        }
      ],
      "total": "<RM per-property Move In total>",
      "blank_rows": 0
    }
  ],
  "move_outs": [
    {
      "property": "<property name>",
      "rows": [
        {
          "resident_name": "<Resident>",
          "account": "<Acc. #>",
          "unit": "<Unit>",
          "unit_type": "<Unit Type>",
          "address": "<Address>",
          "lease_start": "<Lease Start>",
          "lease_end": "<Lease End>",
          "move_in": "<Move In>",
          "move_out": "<Move Out>",
          "expected_move_out": "<Expected Move Out>"
        }
      ],
      "total": "<RM per-property Move Out total>",
      "blank_rows": 0
    }
  ],
  "summary": {
    "date_range": "<RM/display date range>",
    "days_in_range": "<RM value>",
    "move_ins": "<RM summary Move Ins>",
    "move_outs": "<RM summary Move Outs>",
    "net_change": "<RM Net Change in Occupancy>",
    "total_moves": "<RM Total Move Ins / Move Outs>"
  },
  "reconciliation": {
    "opening_date": "<RM opening date>",
    "start_date": "<RM start date>",
    "end_date": "<RM end date>",
    "opening_occupancy": "<RM opening occupancy>",
    "move_ins": "<RM reconciliation Move Ins>",
    "move_outs": "<RM reconciliation Move Outs>",
    "opening_date_move_outs": "<RM opening-date Move Outs adjustment>",
    "ending_date_move_outs": "<RM ending-date Move Outs adjustment>",
    "ending_occupancy": "<RM ending occupancy>"
  }
}
```

Binding rules:

- Preserve RM's property grouping and row order.
- Set `blank_rows` to `0` for live reports. Blank rows are preview/layout slots, not data.
- Pass RM's explicit per-property totals into `total`; the renderer intentionally does not infer totals from row counts.
- Populate `expected_move_out` only for Move Out rows when RM returns it.
- Preserve identifiers such as account/unit numbers as strings so leading zeros are not lost.
- Preformat dates exactly as they should appear in the PDF.
- Populate all Summary and Occupancy Reconciliation values from RM. The Python renderer intentionally does **not** calculate them.
- Signed reconciliation rows are handled visually by the renderer; pass the underlying counts without manually adding `+`/`-` signs unless RM's returned binding is itself textual and the renderer contract requires it.
- If RM does not supply a required reconciliation/summary value, leave that binding blank and flag the report result as partial; do not manufacture the number.

### Generate the PDF with `move_in_move_out.py`

Preferred in-process usage:

```python
from move_in_move_out import build_report

page_count = build_report(
    output_pdf_path,
    report_bindings,
    strict_fit=True,
)
```

Equivalent CLI usage when the runtime executes the renderer as a subprocess:

```bash
python move_in_move_out.py \
  --input report_data.json \
  --output move_in_move_out_report.pdf \
  --strict-fit
```

Use `strict_fit=True` / `--strict-fit` for production reports so oversized values fail visibly instead of being silently ellipsized. If generation fails because data does not fit, return the generation error and preserve the source bindings for debugging; do not switch to an ad-hoc renderer.

Before returning the artifact, verify that the PDF exists and is non-empty. When the runtime supports it, also run the bundled renderer tests after changes to the Python/template package:

```bash
python -m unittest -v test_report.py
```

### User-facing response behavior

For a full report request, return the generated PDF artifact and a concise summary of the RM result. The PDF produced by `move_in_move_out.py` is the canonical formatted output. For a simple question such as "how many move-outs this month?", the skill may answer directly without generating a PDF unless the user asks for the report/export.

When summarizing inline, preserve the same logical order as the PDF: Move Ins, Move Outs, Report Summary, Occupancy Reconciliation. Do not present an independently recomputed reconciliation that conflicts with RM.

## Edge cases
- Zero move-ins or move-outs in the period → report as zero ("No move-ins in [range]"), not a missing-data error; note the report itself prints a blank property name in the total line when a section is empty (e.g., "Total Move Ins for : 0")
- **Expected Move Out present but actual Move Out blank/different** → this is a scheduled/pending move-out, not a completed one — don't count it as a confirmed move-out
- Property filter returns no activity → "No move-ins or move-outs at [property] in [range]."
- Date range unclear or implausible (e.g., entirely in the future with no data yet) → confirm with the user rather than guessing
- Missing permissions on some properties → scope silently to what's accessible, and flag that the occupancy reconciliation figures reflect only the accessible portfolio, not the full one
- Large multi-property pull with many turnover events → summarize by property, offer full export rather than listing every row inline
