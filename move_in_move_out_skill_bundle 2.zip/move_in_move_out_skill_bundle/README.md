# Move In / Move Out — structural report reconstruction

## What this is

A standalone, reusable Python generator that reconstructs the visible layout of
the supplied two-page Move In / Move Out PDF. The code and preview contain no
resident names, account numbers, unit identifiers, property addresses, original
report dates, occupancy values, or movement totals from that PDF.

The supplied PDF's Creator and Producer metadata identify **ActiveReports 17**.
This package is newly written **Python / ReportLab code**, not recovered
ActiveReports source, an RPX/RDLX definition, or a Rent Manager Report Writer
import. No original query, report script, table names, field bindings, filtering
rules, or occupancy accounting policy has been recovered or invented.

## Run

Requires Python 3.10 or newer. Tested with Python 3.13.5 and ReportLab 4.4.9.

```sh
python -m pip install -r requirements.txt
python move_in_move_out.py --output blank_report.pdf
```

The default command produces a two-page, placeholder-only preview. The final two
occupancy reconciliation lines flow to page 2, as in the reference. This is a
natural layout break, not a hard-coded page count.

To supply display values separately:

```sh
python move_in_move_out.py --input empty_report.json --output report.pdf
```

To regenerate an empty input file:

```sh
python move_in_move_out.py --write-template empty_report.json
```

To reject any long text that cannot fit instead of ellipsizing it:

```sh
python move_in_move_out.py --input empty_report.json --output report.pdf --strict-fit
```

## Files

| File | Purpose |
| --- | --- |
| `move_in_move_out.py` | Complete runnable source; all layout constants and column definitions are near the top. |
| `empty_report.json` | Placeholder-only input, separate from the rendering code. |
| `report.schema.json` | JSON Schema describing the accepted input fields. |
| `layout_spec.json` | Framework-independent measurements, section order, columns, and reconciliation sign map. |
| `blank_report.pdf` | Generated two-page structural preview. |
| `requirements.txt` | The single runtime dependency, limited to its tested major version. |
| `test_report.py` | Standard-library unit tests; no test-data files or additional dependency. |

## Recreated structure

US Letter portrait pages, 612 x 792 points; 36-point top and side margins; black
text; 18-point bold section headings; 8-point body text; blue alternating rows
(`#BFE5FF`); approximately 11.2-point data rows; thin rules below table headers.

The report header has the title, property, and date range. It appears on the
first page only. The footer appears on every page with the title, generated
 timestamp, page X of Y, system label, and revision placeholder.

### 1. Move In

Columns, in order: Resident Name, Acc, Unit, Unit Type, Address, Lease Start,
Lease End, Move In, Move Out. Property name is a separate group row. A bold
`Total move ins in property` line follows each property group.

### 2. Move Out

Columns, in order: Resident Name, Acc, Unit, Unit Type, Address, Lease Start,
Lease End, Move In, Move Out, Exp. Move Out. This table uses the reference's
narrower column widths, not the Move In table's widths. A bold
`Total move outs in property` line follows each property group.

### 3. Report Summary

A centered two-column Detail / Value table with six rows, in order:
Date Range; Days In Range; Move Ins; Move Outs; Net Change in Occupancy;
Total Move Ins / Move Outs.

### 4. Occupancy Reconciliation

A centered two-column Detail / Value table. The reference's six lines and
visible signs are preserved:

| Detail binding | Value binding / displayed sign |
| --- | --- |
| Occupancy on opening_date | opening_occupancy |
| Move Ins from start_date to end_date | + move_ins |
| Move Outs from start_date to end_date | - move_outs |
| Move Outs on opening_date | - opening_date_move_outs |
| Move Outs on end_date | + ending_date_move_outs |
| Occupancy on end_date | ending_occupancy |

These signs are visible layout features, **not a claim about the underlying
business formula**. All six values come from the caller. Counts used in signed
rows should be passed without a leading sign. The renderer does not calculate
opening dates, occupancy, totals, day counts, inclusion rules, or reconciliation.
In particular, it does not replace the final occupancy with a simple net-change
calculation. Missing signed values display a blank underline after the sign.

## Data binding

`move_ins` and `move_outs` each accept an array of property groups. Each group has:

- `property`: the group label.
- `rows`: an ordered list of display records.
- `total`: the explicitly supplied total; never inferred from the records.
- `blank_rows`: empty visual row slots used only when `rows` is empty.

The default `blank_rows` settings reproduce the reference's visual density.
They are **not reported totals**. To create a truly empty report with no row
slots, set both to `0`. When actual rows are supplied, they replace the blank
slots. Multiple property groups and arbitrary row counts are supported.
The caller is responsible for choosing, sorting, filtering, and authorizing the
records; the renderer preserves their supplied order.

Record fields are:

```json
{
  "resident_name": "",
  "account": "",
  "unit": "",
  "unit_type": "",
  "address": "",
  "lease_start": "",
  "lease_end": "",
  "move_in": "",
  "move_out": "",
  "expected_move_out": ""
}
```

`expected_move_out` is displayed only in the Move Out table. Missing fields are
blank. Use strings for identifiers and preformatted dates to preserve leading
zeros and the display format you intend. Numeric scalar values and null are
accepted, but arrays, objects, booleans, and non-finite numbers are not valid
cell values. Unknown input keys are rejected to catch binding typos.

Header date range, summary date range, and reconciliation dates are separate
presentation bindings. Populate each explicitly. This is intentional: the
reference uses differing date formats in different sections.

### Calling from another Python application

```python
import json
from pathlib import Path
from move_in_move_out import build_report

bindings = json.loads(Path("empty_report.json").read_text(encoding="utf-8"))
page_count = build_report("report.pdf", bindings, strict_fit=True)
print(f"Generated {page_count} pages")
```

## Fidelity and intentional differences

This is a close visual reconstruction, not a pixel-identical export or the
original vendor runtime. The source uses Arial; the default rendering uses the
PDF Helvetica family. You may supply your own appropriately licensed regular,
bold, and italic TrueType fonts to improve the match or support additional
characters. Font files are not included.

```sh
python move_in_move_out.py --output report.pdf \
  --font-regular /path/to/regular.ttf \
  --font-bold /path/to/bold.ttf \
  --font-italic /path/to/italic.ttf
```

The narrow source columns can clip data. This version shrinks long values to a
minimum of 6.5 points, then ellipsizes with a warning instead of allowing text
to overlap. Use `--strict-fit` to fail rather than truncate. To allocate more
space, edit the explicit column positions and widths in the Python source.

The standard Helvetica path rejects text outside its supported Windows-1252
character range and asks for custom fonts instead of silently emitting boxes.
Supply fonts that contain the glyphs needed for your data.

Detail table headers and property labels repeat when a detail table continues
onto a later page. Summary headers do not repeat by default, preserving the
reference's sparse second page. To repeat Detail / Value on summary continuation
pages, use `--repeat-summary-headers`.

System branding, revision, and generated timestamp are placeholders rather than
copied vendor metadata. The new PDF identifies itself as a reconstruction in
its Creator metadata. The source PDF and source-page images are not bundled.

## Tests

```sh
python -m unittest -v test_report.py
```

Tests cover the two-page blank layout, empty sections, dynamic pagination,
multiple property groups, section order, blank totals, the six reconciliation
lines, strict overflow handling, invalid input, and PDF generation. The preview
was also rendered and visually checked separately.

## Implementation reference

ReportLab's official PDF canvas documentation was used to check the rendering
API. The report's layout and labels come from the supplied PDF, not from an
external report template.

https://docs.reportlab.com/reportlab/userguide/ch2_graphics/
