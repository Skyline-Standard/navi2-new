"""Run with: python -m unittest -v test_report.py"""
import tempfile
import unittest
from pathlib import Path

from move_in_move_out import (
    Composer, ReportData, blank_template, build_report, _fit,
    BODY_BOTTOM, MOVEMENT_KEYS, MOVE_IN_COLUMNS, MOVE_OUT_COLUMNS,
)


def all_text(pages):
    return [args["text"] for page in pages for op, args in page if op == "text"]


class ReportTests(unittest.TestCase):
    def test_blank_layout_has_two_pages_and_empty_detail_records(self):
        data = blank_template()
        self.assertTrue(all(not g["rows"] for k in ("move_ins", "move_outs") for g in data[k]))
        self.assertTrue(all(v == "" for v in data["summary"].values()))
        pages = Composer(ReportData.from_dict(data)).compose()
        self.assertEqual(len(pages), 2)
        self.assertEqual(all_text([pages[1]]), ["Move Outs on [End]", "+ _____", "Occupancy on [End]"])

    def test_section_order_and_columns(self):
        texts = all_text(Composer(ReportData.from_dict(blank_template())).compose())
        ordered = [texts.index(s) for s in ("Move In", "Move Out", "Report Summary", "Occupancy Reconciliation")]
        self.assertEqual(ordered, sorted(ordered))
        self.assertEqual(len(MOVE_IN_COLUMNS), 9)
        self.assertEqual(len(MOVE_OUT_COLUMNS), 10)
        self.assertEqual(MOVE_OUT_COLUMNS[-1].label, "Exp. Move Out")
        self.assertNotEqual(MOVE_IN_COLUMNS[0].width, MOVE_OUT_COLUMNS[0].width)

    def test_no_slots_gives_a_one_page_empty_structure(self):
        data = blank_template()
        for section in ("move_ins", "move_outs"):
            data[section][0]["blank_rows"] = 0
        self.assertEqual(len(Composer(ReportData.from_dict(data)).compose()), 1)

    def test_multipage_and_multiple_property_groups(self):
        data = blank_template()
        data["move_ins"] = [
            {"property": "[Group A]", "blank_rows": 130, "total": "", "rows": []},
            {"property": "[Group B]", "blank_rows": 7, "total": "", "rows": []},
        ]
        pages = Composer(ReportData.from_dict(data)).compose()
        self.assertGreater(len(pages), 2)
        self.assertGreater(all_text(pages).count("[Group A]"), 1)
        self.assertIn("[Group B]", all_text(pages))
        for page in pages:
            for op, args in page:
                if op == "rect":
                    self.assertLessEqual(args["top"] + args["height"], BODY_BOTTOM + 0.001)
                elif op == "text":
                    self.assertLess(args["top"], BODY_BOTTOM)

    def test_actual_rows_replace_blank_slots(self):
        data = blank_template()
        for section in ("move_ins", "move_outs"):
            data[section][0]["rows"] = [{key: "" for key in MOVEMENT_KEYS}]
            data[section][0]["blank_rows"] = 1000
        pages = Composer(ReportData.from_dict(data)).compose()
        self.assertEqual(len(pages), 1)

    def test_reconciliation_is_not_calculated(self):
        data = blank_template()
        data["reconciliation"].update({
            "move_ins": "[IN]", "move_outs": "[OUT]",
            "opening_date_move_outs": "[OPEN-OUT]",
            "ending_date_move_outs": "[END-OUT]", "ending_occupancy": "[PROVIDED]",
        })
        texts = all_text(Composer(ReportData.from_dict(data)).compose())
        for text in ("+ [IN]", "- [OUT]", "- [OPEN-OUT]", "+ [END-OUT]", "[PROVIDED]"):
            self.assertIn(text, texts)

    def test_invalid_inputs_are_rejected(self):
        for value in ([], "invalid", {"unknown": 1}, {"move_ins": {}}, {"summary": []},
                      {"summary": {"move_ins": True}}, {"summary": {"move_ins": float("nan")}},
                      {"move_outs": [{"blank_rows": -1}]},
                      {"move_ins": [{"rows": [{"unknown_field": ""}]}]}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                ReportData.from_dict(value)

    def test_preserves_zero_and_leading_zeros(self):
        report = ReportData.from_dict({"summary": {"move_ins": 0},
                                      "move_ins": [{"rows": [{"account": "00001"}]}]})
        self.assertEqual(report.summary["move_ins"], "0")
        self.assertEqual(report.move_ins[0].rows[0]["account"], "00001")

    def test_overflow_strict_mode(self):
        with self.assertRaises(ValueError):
            _fit("[Text that cannot fit in a narrow column]", "Helvetica", 8, 18, True)

    def test_pdf_generation(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "report.pdf"
            self.assertEqual(build_report(path, strict_fit=True), 2)
            self.assertTrue(path.read_bytes().startswith(b"%PDF-"))
            self.assertTrue(path.read_bytes().rstrip().endswith(b"%%EOF"))

    def test_failed_render_does_not_overwrite_existing_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "report.pdf"
            path.write_bytes(b"existing file")
            data = blank_template()
            data["move_ins"][0]["rows"] = [{"account": "[Does not fit in the account column]"}]
            with self.assertRaises(ValueError):
                build_report(path, data, strict_fit=True)
            self.assertEqual(path.read_bytes(), b"existing file")

    def test_summary_headers_can_repeat(self):
        pages = Composer(ReportData.from_dict(blank_template()), repeat_summary_headers=True).compose()
        self.assertEqual(all_text([pages[1]])[:2], ["Detail", "Value"])


if __name__ == "__main__":
    unittest.main()
